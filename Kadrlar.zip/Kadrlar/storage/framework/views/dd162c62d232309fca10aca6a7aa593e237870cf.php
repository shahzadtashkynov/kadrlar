<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ishgarin arzasy</title>
    <style>
        body{
            font-size: 1.2em;
        }
    .header{
        width: 40%;
        float: right;
        margin: 5%;
    }
    
    .main{
        clear: both;
        width: 90% ;
        margin: 0 auto;
        text-align: center;
    }
    .footer
    {
        margin: 10% ;
    }
    @media  print {
    .print{
        display: none;
        }
    }
    </style>
</head>
<body>
    <button class="print" onClick="window.print()">Print this page</button>
    <div class="header">
        Telekeçi Annageldiýew Çaryýara 
        Ahal welaýatynyň Gökdepe etrabynyň ýaşaýjysy
        <?php echo e($worker->surname); ?> <?php echo e($worker->name); ?> tarapyndan
    </div>
    <div class="main">
        <b>Arza</b><br>
        Meni
        <?php echo e($worker->job); ?> edip işe almagyňyzy soraýaryn

    </div>
    <div class="footer">
        <h3>Goly__________                "_____"_____________20____ý</h3>
    </div>   
</body>
</html>