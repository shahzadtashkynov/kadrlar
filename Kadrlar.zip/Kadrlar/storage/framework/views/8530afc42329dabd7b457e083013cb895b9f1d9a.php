
		<table class="table-solid m-1">
			<tr>
					<td>Ishe alyan</td>
                <td>
					<select  class="select" name="owner" id="">
						<option value="bashlyk">Ç.Annageldiýew</option>
                        <option value="archalyk">Arçalyk HJ</option>
                    </select>
                </td>
            </tr>
            <tr>
				<td>Işgäriň ady</td>
                <td><input type="text" required name="name" class="input"
                    placeholder="Jumamyrat"></td>
				</tr>
				<tr>
					<td>Suraty</td>
					<td> <input type="file" name="photo" >
					</td>
				</tr>
				<tr>
				<td>Işgäriň familiyasy</td>
                <td><input type="text" required name="surname" class="input"
                    placeholder="Odekow"></td>
				</tr>
				<tr>
				<td>Işgäriň atasynyň ady</td>
                <td><input type="text" required name="fname" class="input"
                    placeholder="Orayewiç"></td>
				</tr>
				<tr>
					<td>Işe alynýan wezipesi</td>
					<td><input type="text" name="job" 
					placeholder="Wezipesi" class="input"></td>
				</tr>
				<tr>
				<td>Aýlygy</td>
				<td><input type="text" name="salary" class="input"
                    placeholder="800"></td>
				</tr>
                <td>Ýaşaýan ýeri</td>
                <td><input type="text" name="adress" class="input"
                    placeholder="Yashayan yeri"></td>
            <tr>
				<td>Pasport belgisi</td>
				<td><input type="text" name="passport_no" 
				placeholder="M-m:I-BN 434343" class="input"></td>
            </tr>
            <tr>
				<td>Pasport kim tarapyndan berlen</td>
				<td><input type="text" name="passport_who"
				 placeholder="M-m: Ashgabat şäher häkimligi"
				  class="input"></td>
			</tr>
			<tr>
				<td>Passport kopiyasy</td>
				<td><input type="file" name="cpath"></td>
			</tr>
            <tr>
				<td>Zahmet depderçesiniň belgisi</td>
				<td><input type="text" required name="trud_no" 
				placeholder="M-m: 656565" 
				 class="input"></td>
            </tr>
            <tr>
                <td>Telefon</td>
				<td><input type="text" name="phone" 
				placeholder="M-m:+99365123456 ýa-da 864123456" 
				class="input"></td>
            </tr>
		</table>
		<input type="hidden" name="status" value="working">
		<input type="submit" class="btn-green submit" value="Kabul etmek">
