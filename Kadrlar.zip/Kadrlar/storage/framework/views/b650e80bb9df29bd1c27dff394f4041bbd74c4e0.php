<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ishgar barada maglumat</title>
    <style>
        body *{
            font-size: 1.1em;
        }
        img{
            width: 65px;
            height: 100px;
            border: 1px solid #000; 
            float: right;
            margin-right: 10%;
            margin-bottom: 3%;
        }
    .table{
        clear: both;
        width: 80%;
        margin: 0 auto;
        border:3px solid #000;
        padding: 0; 
    }
     td{
        margin: 0;
        padding: 1%;
        border: 1px solid #000;
    }
    @media  print {
    .print{
        display: none;
        }
    a{

        text-decoration: none;
    }
    }
    </style>
</head>
<body>
        <button class="print"  onClick="window.print()">Print/Печать/Çap etmek</button>
<a href="/<?php echo e($worker->phpath); ?>">
<img src="/<?php echo e($worker->phpath); ?>" alt="Surat yeri"  width="3cm" height="4cm">
    </a>
    <table class="table">
        <tr>
            <td>Familiyasy</td>
            <td><?php echo e($worker->surname); ?></td>
        </tr>
        <tr>
            <td>Ady:</td>
            <td><?php echo e($worker->name); ?> </td>
        </tr>
        <tr>
            <td>Atasynyň ady:</td>
            <td><?php echo e($worker->fname); ?></td>
        </tr>
        <tr>
            <td>Ýaşaýan salgysy: </td>
            <td><?php echo e($worker->adress); ?>

            </td>
        </tr>
        <tr>
            <td>Pasport seriýasy,№ ,
                tarapyndan berlen:
            </td>
            <td>
                <a href="/<?php echo e($worker->passport_cpath); ?>">
                    <?php echo e($worker->passport_no); ?> <?php echo e($worker->passport_who); ?>  
                </td>
                </a>
            </td>
        </tr>
        <tr>
            <td>Işe başlan wagty</td>
            <td><?php echo e($worker->in_date); ?></td>
        </tr>
        <tr>
            <td>Şertnama № <br>Registrasiýa №</td>
            <td>
            <a href="/contract/<?php echo e($worker->id); ?>">
                Şertnama №7/19
            </a>
            </td>
        </tr>
        <tr>
            <td>Atly pensiýa hasabynyň belgisi</td>
            <td> <?php echo e($worker->trud_no); ?></td>
        </tr>
        <tr>
            <td>Käri:</td>
            <td><?php echo e($worker->job); ?></td>
        </tr>
        <tr>
            <td>Telefon: </td>
            <td><?php echo e($worker->phone); ?></td>
        </tr>
        <tr>
            <td>Işden çykan wagty</td>
            <td><?php echo e($worker->out_date); ?></td>
        </tr>
        <tr class="print">
            <td>Goşmaça</td>
            <td>
                <a href="/birja/<?php echo e($worker->id); ?>">Birja hat
                </a>
            </td>
        </tr>
        <tr class="print">
            <td>Goşmaça</td>
            <td>
                <a href="/workers/arzain/<?php echo e($worker->id); ?>">
                    Arza giriş
                </a>
            </td>
        </tr>
        <tr class="print">
            <td>Goşmaça</td>
            <td>
                <a href="/workers/arzaout/<?php echo e($worker->id); ?>">
                    Arza çykyş
                </a>
            </td>
        </tr>
        <tr class="print">
            <td>Goşmaça</td>
            <td>
                <a href="/contract2/<?php echo e($worker->id); ?>">
                    Şertnama 2
                </a>
            </td>
        </tr>
        <tr class="print">
            <td>Goşmaça</td>
            <td>
                <a href="/buyruk/<?php echo e($worker->id); ?>">
                    Buyruk
                </a>
            </td>
        </tr>
    </table>
</body>
</html>