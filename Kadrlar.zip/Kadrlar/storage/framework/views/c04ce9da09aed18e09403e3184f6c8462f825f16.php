<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Vue js + Axios test</title>
<script src="/js/app.js"></script>
<script src="/js/main.js"></script>
<style>
body{
    background: black;
    color: beige;
}
</style>
</head>
<body>
    <h1>Vue Axios test</h1>
    <div id="root">
        <Image></Image>
    </div>
</body>
</html>