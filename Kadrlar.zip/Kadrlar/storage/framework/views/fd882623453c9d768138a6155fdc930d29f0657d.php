<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1 class="header">
            Telekeçi Annageldiyew "Arçalyk" suw zawodynyň we "Arçalyk" HJ-nyň işgärler sanawy
        </h1>
        <table class="table m-1">
            <tr>
                <th>№</th>
                <th>Ady</th>
                <th>Familiyasy</th>
                <th>Wezipesi</th>
                <th>Aylyk zahmet haky</th>
                <th>Işe giren wagty</th>
                <th>salgysy</th>
                <th>Telefony</th>
            </tr>
            <tr>
                <td>1</td>
                <td>Amanow</td>
                <td>Aman</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>2</td>
                <td>Gurbanow</td>
                <td>Gurban</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td>3</td>
                <td>Bayramow</td>
                <td>Serdar</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </table>
        <a href="empinsert.html" class="btn-green right m-1">Taze ishgar</a>
        <button class="btn-red right m-1">Ishden chykarmak</button>
        <button class="btn-blu right m-1">Wezipesini chalyshmak</button>
    </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>