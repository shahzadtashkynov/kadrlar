<?php $__env->startSection('content'); ?>
    <h1>
        Changejob 
    </h1>
    <table class="table m-1">
            <tr>
                <th>№</th>
                <th>Ady</th>
                <th>Familiyasy</th>
                <th class="job">Wezipesi</th>
                <th class="salary">Aylyk zahmet haky</th>
                <th class="adress">Salgysy</th>
                <th class="phone">Telefony</th>
            </tr>
            <form action="/changejob" method="post">
            <tr> 
                <td><?php echo e($worker->id); ?></td>
                <td><?php echo e($worker->name); ?></td>
                <td><?php echo e($worker->surname); ?></td>
                <td>
                        <input type="hidden" name="_token"
                        value="<?php echo e(csrf_token()); ?>">
                        <input type="hidden" name="id" value="<?php echo e($worker->id); ?>">    
                        <input type="text" name="job" placeholder="<?php echo e($worker->job); ?>" class="input">
                    </td>
                    <td class="salary"><?php echo e($worker->salary); ?></td>                
                    <td class="adress"><?php echo e($worker->adress); ?></td>
                    <td class="phone"><?php echo e($worker->phone); ?></td>
                </tr>
            </table>        
            <input type="submit" value="Wezipesini chalyshmak" class="btn-blu">
            </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>