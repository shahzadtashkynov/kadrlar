<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Zahmet şertnamasy</title>

    <style>
        body{
            background: gray;
        }
            .container{
                width:21cm;
                height: 29.5cm;
                background: white;
                margin: 0 auto;
                padding: 3%;
            }
    .header{
        width: 80%;
        margin: 0 auto;
        margin-top: 5%;
        text-align: center;
        }
    .m2{
        margin: 2%;
    }
    .left{
        float: left;
    }
    .right{
        float: right;
    }
    .center{
        width:auto;
        margin: 0 auto;
    }
    .small{
        margin: 0;
        padding: 0;
        font-size: 8px; 
        text-align: center;
        clear: both;
    }
    .main{
        clear: both;
        width: 90%;
        margin: 0 auto;
        font-size: 1em;
    }
    .text{
        margin: 0;
    }
    u{
        margin: 0;
    }
    @media  print {
        .print {
            display: none;
        }
    }
    </style>
</head>
<body>
    <div class="container">
        <button class="print" onclick="window.print()"> Print</button>
        <h3 class="header">
            Zähmet şertnamasy  17/19
        </h3>
        <span  class="left m2">
            Aşgabat ş
        </span>
        <span class="right m2">
            "07" 05 2019
        </span>
        <div class="main m2">
                      
                Biz aşakda gol çekenler Telekeçi Annageldiýew Çarýar Bel.al. şah 0303567 berlen senesi <br>
                <h6 class="small">(F.A.A.a)</h6><br>
                2018-nji ýylyň "08" "Maý" ŞSB 20212250236 "Iş beriji" diýlip atlandyrylýan , bir tarapdan, we <br>
                <u>
                    <?php echo e($worker->surname); ?> <?php echo e($worker->name); ?> <?php echo e($worker->fname); ?>__<?php echo e($worker->passport_no); ?>__ <?php echo e($worker->passport_who); ?>_____
                </u>
                <br> 
                <h4 class="text">
                    Tarapyndan berlen şu salgyda ýaşaýan  
                </h4>
                <u>_
                    <?php echo e($worker->adress); ?>____
                </u><br>
                mundan beýläk "işgär diýlip atlandyrylyp, beýleki tarapdan, aşakdakylar barada şu şertnamany baglaşdylar:
                <h4 class="header"> 
                    1. Şertnamanyň meselesi
                </h4>
                1.1 "Iş beriji" işe kabul edýär, "işgär" bolsa aşakdaky wezipeleri ýerine ýetirmek üçin ____<?php echo e($worker->in_date); ?>____ <br>
            möhletsiz işe girýär <u>__________<?php echo e($worker->job); ?>__________</u>
                <h6 class="small">(işleriň häsiýeti we görnüşi)</h6>
                <h4 class="header">2. Iş hakyny tölemek </h4>
                <p>2.1 Telekeçi Annageldiýew Çarýar "iş beriji" ýerine ýetirilen iş üçin her aýda "işgäre" <?php echo e($worker->salary); ?> manat möçberde iş <br> 
                    hakyny töleýar.
                   2.2 "Iş beriji" işlenen döwür üçin her ___ gününe çenli iş hakyny tölemage borçludyr</p>
                <h4 class="header">3. Taraplaryň borçlary </h4>
                <p class="text">3.1 "Iş beriji" "işgär" üçin wezipelerini kadaly ýerine ýetirmek üçin zerur bolan zähmet şertlerini döretmage <br>
                    borçlanýar. <br>
                    3.2 "Işgär" öz borçlaryny ak ýürek bilen ýerine ýetirmäge, özüne ynanylan emläge we harytlara aýawly garamagy <br>
                    üpjün etmäge borçlanýar.
                </p>
                <h4 class="header">5. Şertnamanyň hereket edýän möhleti </h4>
                <p>5.1 Şu şertnama gol çekilen wagtyndan güýje girýär hem-de möhletsiz hereket edýär</p>
                <h4 class="header"> 6. Beýleki şertler</h4>
                <p class="text">6.1 Şu şertnama ähli üýtgetmeler we goşmaçalar, şeýle hem onuň hereketiniň bes edilmegi üç gün möhletde <br>
                döwlet salgyt gullugynyň ýerli edarasyna bu barada habar bermek bilen ýazmaça görnüşde amala aşyrylýar. <br>
                    6.2 Şu şertnama üç asyl nusgada düzüldi, üçünji nusga döwlet salgyt gullugynyň ýerli edarasynda  galýar</p>
                    <h4 class="header">7. Taraplaryň gollary </h4>
                    <p class="left"> "Iş beriji"__________________</p> <p class="right">                        "Işgär"_____________________</p>
        </div>
    </div>
</body>
</html>