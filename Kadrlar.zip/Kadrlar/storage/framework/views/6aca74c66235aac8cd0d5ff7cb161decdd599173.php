<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1 class="header">
            Telekeçi Annageldiyew "Arçalyk" suw zawodynyň we "Arçalyk" HJ-nyň işgärler sanawy
        </h1>
        <table class="table m-1">
            <tr>
                <th>№</th>
                <th>Ady</th>
                <th>Familiyasy</th>
                <th class="job">Wezipesi</th>
                <th class="salary">Aylyk zahmet haky</th>
                <th class="adress">Salgysy</th>
                <th class="phone">Telefony</th>
                <th class="operations">Amallar</th>
                <th class="operations">Boshatmak</th>
            </tr>
            <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr> 
                <td><?php echo e($worker->id); ?></td>
                <td><?php echo e($worker->name); ?></td>
                <td>
                    <a href="/workers/<?php echo e($worker->id); ?>">   
                    <?php echo e($worker->surname); ?>

                    </a>
                </td>
                <td>
                    <?php echo e($worker->job); ?>

                </td>
                <td class="salary"><?php echo e($worker->salary); ?></td>                
                <td class="adress"><?php echo e($worker->adress); ?></td>
                <td class="phone"><?php echo e($worker->phone); ?></td>
                <td class="operations">
                    <form action="/changejob" method="get">
                    <input type="hidden" name="id" value="<?php echo e($worker->id); ?>">
                    <input type="submit" value="Wezipe chalyshmak" class="btn-blu">
                    </form>                         
                </td>
                <td>
                    <form action="/status" method="get">
                    <input type="hidden" name="id" value="<?php echo e($worker->id); ?>">
                <?php if($worker->status==='working'): ?>
                <input type="hidden" name="status" value="deactivate">
                    <input type="submit" value="Boshatmak" class="btn-red">
                <?php else: ?>
                <input type="hidden" name="status" value="working">
                    <input type="submit" value="Gaytarmak" class="btn-green">
                <?php endif; ?>
                </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <a href="/create" class="btn-green right m-1">Taze ishgar</a>
        </div>
  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>