<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/test', function () {
	return view('vue');
});
Route::any('/data','WorkersController@data');
Route::get('/','WorkersController@index');
Route::get('/workers','WorkersController@index');
Route::get('/create','WorkersController@create');
Route::get('/changejob', 'WorkersController@getchangejob');
Route::get('/status','WorkersController@status');
Route::get('/workers/{id}','WorkersController@show');
Route::get('/getphotos','WorkersController@getphotos');
Route::get('/contract/{id}','WorkersController@contract');
Route::get('/workers/arzain/{id}','WorkersController@arzain');
Route::get('/workers/arzaout/{id}','WorkersController@arzaout');
Route::get('/contract2/{id}','WorkersController@contract2');
Route::get('/buyruk/{id}','WorkersController@buyruk');
Route::get('/birja/{id}','WorkersController@birja');


Route::post('/changejob', 'WorkersController@postchangejob');
Route::post('/store','WorkersController@store');
Route::post('/postphotos','WorkersController@photos');


