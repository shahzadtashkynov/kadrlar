<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Goşundy</title>
    <style>
    @media print
    {
        .print {
            display: none;
        }
    }
    small{
        font-size: 0.6em;
    }
    .shapka{
        width:50%;
        margin: 0% 4% 0% 3%;
        float: right;text-align: justify;
    }
    .center{
        clear: both;
        text-align: center;
    }
    .ml-5{
        clear: both;
        margin-left: 5%;
    }
    .block{
        border: 1px solid;
        margin: 0% 1% 0% 1%;
        padding: 0% 1% 0% 1%;
    }
    body{
        background: gray;
    }
    .container{
            width:21cm;
            height: 29cm;
            background: white;
            margin: 0 auto;
            padding: 3%;
        }
    </style>
</head>
<body>
    <div class="container">
        <button class="print" onclick="window.print()"> Print</button>
    <div class="shapka">
    <h4> Türkmenistanyň Baş döwlet salgyt gullugynyň
         başlygynyň 2010-njy ýylyň  1-nji fewralyndaky 05-Ö belgili buýrugy bilen tassyklanan, hakyna 
         tutma zähmeti ulanýan iş beriji - şahsy tarapyň we  işgäriň arasynda baglaşylan zähmet
         şertnamasyny bellige almagyň tertibi hakyndaky 
        Düzgünnama 1 belgili goşundy 
    </h4>
    </div>
    <h4 class="ml-5"> __________<U>Büzmeýin etraby</U>
         _____ salgyt bölümine</h4>
<h4 class="center">Iş beriji - şahsy adamyň we işgäriň arasyndaky zähmet şertnamasyny 
    <br> bellige almak barada 
    <br>Arza
</h4>
<div class="block">
    <h4>
        1.Iş beriji - şahsy tarap barada maglumatlar :
        Familiýasy,<u>_____Annageldiýew_______________</u>
        Ady,____________ <u>Çarýar</u>_____________________
        Atasynyň ady_______________________________________
    </h4>
</div>
<div class="block">
    <h4>
        2. Iş beriji tarapyň şahsyýetini tassyklaýan resminamanyň görnüşi :
        <br> ____________Pasport______________________________________________
        <br>Seriýasy ______I-BN________, belgisi __308254__, berilen senesi 20_07__ý. _Awgust_"_21_"
        <br>Kim tarapyndan we haçan resminama berilen  ___Ahal welaýatynyň Ruhabat etrap häkimligi__ 
    </h4>
</div>
<div class="block">
    <h4>
        3. Iş beriji - şahsy tarapyň salgyt belgisi (berlen bolsa) __202122502306 _____
    </h4>
</div>
<div class="block">
    <h4>4.Iş beriji - şahsy tarapyň ýaşaýan ýeriniň salgysy:
        <br>Poçta indeksi __________Welaýat ______________________________
        <br>Etrap_____Büzmeýin________Şäher____Aşgabat____________________
        <br>Ilatly ýer(oba, şäherçe we ş.m.)_______Herrikgala_____________
        <br>Etrapça ___________Şaýoly, köçe, geçelge ____A.Myradow________
        <br>Jaý_____49______Korpus_______________Öý_______________________ 
    </h4>
</div>
<div class="block">
    <h4>
        5.Hususy telekeçiniň döwlet tarapyndan bellige alnandygy baradaky şahadatnama
        <br><small>(Iş beriji - hususy telekeçiler üçin):</small>
        <br>_______Aşgabat şäheriniň Büzmeýin etraby ___________ salgyt bölüminiň ýerli
        <br><small>(döwlet salgyt gullugynyň ýerli edarasynyň ady)</small>
        <br>edarasy tarapyndan 2018_ýylyň___Maý___"08" berlen hususy telekeçiniň bellige alyş 
        <br>şahadatnamasy  ___0303567_____, reýestr belgisi _____________________
        <br>_____________________________________________________________________
        <br>20____ý ____________"____"
    </h4>
</div>
<div class="block">
    <h4>
        6.Işgär barada maglumat :
    <br>  Familiýasy, _____{{$worker->surname}}________________________
    <br> Ady, ___________________{{$worker->name}}_________________________
    <br> Atasynyň ady  ______________{{$worker->fname}}___________________
    </h4>
</div>
<div class="block">
    <h4>
        7.Işgäriň şahsyýetini tassyklaýan resminamanyň görnüşi: 
        <br>____________Pasport______________________________________________
        <br> Belgisi {{$worker->passport_no}} berlen senesi 2015 ý. 09 "06"_
    </h4>
</div> 
</div> 
</body>
</html>