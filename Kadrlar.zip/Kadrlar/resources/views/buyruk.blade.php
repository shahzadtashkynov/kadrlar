<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Buyruk</title>
    
    <style>
        body{
            background: gray;
        }
        .container{
            background: white;
            width:21cm;
            height: 29cm;
            margin: 0 auto;
            padding: 3%;
        }
        .main-header{
            width: 80%;
            margin: 0 auto; 
            text-align: center;
            font-size: 2em;
            font-family: Arial, Helvetica, sans-serif;
            color: #9981B7;
            }
        .cl5{
            color: #9981B7;
            width: 45%;
            text-align: center
        }
        .lt{
            float: left;
        }
        .rt{
            float: right;
        }

        .content{
            clear: both;
            display: flex;
        }
        .center{
            clear: both;
            width: fit-content; 
            margin: 0 auto;
        }
        .ltblock{
            width: 45%; 
        }
        .rtblock{
            width: 45%;
        }
        .btsection{
            width: 95%;
            margin: 0 auto;
            display: flex;
        }
        .bold{  
            margin: 0%;
            clear: both;   
            height: 3px;
            background: #9981B7;
        }
        .thin
        {
            height: 1px;
            margin: 0 0 0 0;
            background: #E1E1E1;
        }
        .footer{
            margin: auto auto 0 auto;
            float: bottom;
            font-family: Arial, Helvetica, sans-serif;
            color: #9981B7;
        }
        .textft{
            color: #9981B7;
            font-size: 0.6em;
            margin: 0%;
        }

        @media print{
            .print{
                display: none;
            }
            .container{
            background: white;
            width:21cm;
            height: 29cm;
            margin: 0 auto;
            padding: 3%;
        }
        .main-header{
            width: 80%;
            margin: 0 auto; 
            text-align: center;
            font-size: 2em;
            font-family: Arial, Helvetica, sans-serif;
            color: #9981B7;
            }
        .cl5{
            color: #9981B7;
            width: 45%;
            text-align: center
        }
        .lt{
            float: left;
        }
        .rt{
            float: right;
        }

        .content{
            clear: both;
            display: flex;
        }
        .center{
            clear: both;
            width: fit-content; 
            margin: 0 auto;
        }
        .ltblock{
            width: 45%; 
        }
        .rtblock{
            width: 45%;
        }
        .btsection{
            width: 95%;
            margin: 0 auto;
            display: flex;
        }
        .bold{  
            margin: 0%;
            clear: both;   
            height: 3px;
            background: #9981B7;
        }
        .thin
        {
            height: 1px;
            margin: 0 0 0 0;
            background: #E1E1E1;
        }
        .footer{
            position: absolute;
            bottom: 15px;
            margin: 0 auto;
            
            font-family: Arial, Helvetica, sans-serif;
            color: #9981B7;
        }
        .textft{
            color: #9981B7;
            font-size: 0.6em;
            margin: 0%;
        }

        }
         </style>
</head>
<body>
    <div class="container">
        <button class="print" onclick="window.print()"> Print</button>
        <h1 class="main-header">
            Telekeçi 
            <br>Annageldiýew Çarýar
        </h1>
        <div class="cl5 lt">Telekeçi: Ç.Annageldiýew, Türkmenistan 
            Aşgabat ş. Abadan etr, Abadan şaýoly, 265A
            Tel:+9931233-36-53; faks:+9931233 42 03
            E-mail:www.arсhalyk.com
        </div>
        <div class="cl5 rt">Enterpreneur: Ch.Annageldiyew, Turkmenistan 
            Ashgabat city. Abadan district, Abadan avenue, 265A 
            Tel:+9931233-36-53; faks:+9931233 42 03
            E-mail:www.arсhalyk.com
        </div>
        <hr class="bold">
        <hr class="thin">
        <h3 class="center">
            1
        </h3>
        <div class="content">
            <h4 class="ltblock" >
                {{$worker->surname}}
                {{$worker->name}}
                {{ $worker->fname}}
            </h4>
            <h4 class="rtblock">
                {{date('Y-m-d')}} seneden {{$worker->job}}
                wezipesine bellemeli we Zähmet şertnamasynda
                kesgitlenen möçberde aýlyk zähmet hakyny tölemeli. 
                <b>Esas</b>№33/17 belgili zähmet şertnamasy,
                <br>{{$worker->surname}}{{str_limit($worker->name,1,'.')}}
                {{str_limit($worker->fname,1,'.')}}
            </h4>
        </div>
        <div class="btsection">
                <h4 class="ltblock">
                    "Arçalyk" agyz suw 
                    <br>zawodynyň ýolbaşçysy
                    <br>Telekeçi: 
                </h4>
                <h4 class="rtblock">
                    Ç. Annageldiyew
                </h4>
            </div>
            <div class="footer">
                    <hr class="bold">   
                    <hr class="thin">
                   
        <h4 class="textft">Telekeçi: Ç.Annageldiýew, Türkmenistan 
            Aşgabat ş. Abadan etr, Abadan şaýoly, 265A
            Tel:+9931233-36-53; faks:+9931233 42 03
            E-mail:www.arсhalyk.com
        </h4>
        <h4 class="textft">Enterpreneur: Ch.Annageldiyew, Turkmenistan 
            Ashgabat city. Abadan district, Abadan avenue, 265A 
            Tel:+9931233-36-53; faks:+9931233 42 03
            E-mail:www.arсhalyk.com
        </h4>
            </div>
</body>
</html>