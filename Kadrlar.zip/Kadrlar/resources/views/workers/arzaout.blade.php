<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ishgarin arzasy</title>
    <style>
        body{
            font-size: 1.2em;
        }
    .header{
        width: 40%;
        float: right;
        margin: 5%;
    }
    
    .main{
        clear: both;
        width: 90% ;
        margin: 0 auto;
        text-align: center;
    }
    .footer
    {
        margin: 10% ;
    }
    </style>
</head>
<body>
    <div class="header">
        Telekeçi Annageldiýew Çaryýara 
        "Arçalyk " gazly, şireli, arassa agyz suw zawodynyyň işgäri {{$worker->surname}} {{$worker->name}} tarapyndan
    </div>
    <div class="main">
        <b>Arza</b><br>
        Meni öz islegim boýunça işden boşatmagyňyzy haýyş edýärin
    </div>
    <div class="footer">
        <h3>Goly__________                "_____"_____________20____ý</h3>
    </div>   
</body>
</html>