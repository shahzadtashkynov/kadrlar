<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ishgar barada maglumat</title>
    <style>
        body *{
            font-size: 1.1em;
        }
        img{
            width: 65px;
            height: 100px;
            border: 1px solid #000; 
            float: right;
            margin-right: 10%;
            margin-bottom: 3%;
        }
    .table{
        clear: both;
        width: 80%;
        margin: 0 auto;
        border:3px solid #000;
        padding: 0; 
    }
     td{
        margin: 0;
        padding: 1%;
        border: 1px solid #000;
    }
    @media print {
    .print{
        display: none;
        }
    a{

        text-decoration: none;
    }
    }
    </style>
</head>
<body>
        <button class="print"  onClick="window.print()">Print/Печать/Çap etmek</button>
<a href="/{{$worker->phpath}}">
<img src="/{{$worker->phpath}}" alt="Surat yeri"  width="3cm" height="4cm">
    </a>
    <table class="table">
        <tr>
            <td>Familiyasy</td>
            <td>{{$worker->surname}}</td>
        </tr>
        <tr>
            <td>Ady:</td>
            <td>{{$worker->name}} </td>
        </tr>
        <tr>
            <td>Atasynyň ady:</td>
            <td>{{$worker->fname}}</td>
        </tr>
        <tr>
            <td>Ýaşaýan salgysy: </td>
            <td>{{$worker->adress}}
            </td>
        </tr>
        <tr>
            <td>Pasport seriýasy,№ ,
                tarapyndan berlen:
            </td>
            <td>
                <a href="/{{$worker->passport_cpath}}">
                    {{$worker->passport_no}} {{$worker->passport_who}}  
                </td>
                </a>
            </td>
        </tr>
        <tr>
            <td>Işe başlan wagty</td>
            <td>{{$worker->in_date}}</td>
        </tr>
        <tr>
            <td>Şertnama № <br>Registrasiýa №</td>
            <td>
            <a href="/contract/{{$worker->id}}">
                Şertnama №7/19
            </a>
            </td>
        </tr>
        <tr>
            <td>Atly pensiýa hasabynyň belgisi</td>
            <td> {{$worker->trud_no}}</td>
        </tr>
        <tr>
            <td>Käri:</td>
            <td>{{$worker->job}}</td>
        </tr>
        <tr>
            <td>Telefon: </td>
            <td>{{$worker->phone}}</td>
        </tr>
        <tr>
            <td>Işden çykan wagty</td>
            <td>{{$worker->out_date}}</td>
        </tr>
        <tr class="print">
            <td>Goşmaça</td>
            <td>
                <a href="/birja/{{$worker->id}}">Birja hat
                </a>
            </td>
        </tr>
        <tr class="print">
            <td>Goşmaça</td>
            <td>
                <a href="/workers/arzain/{{$worker->id}}">
                    Arza giriş
                </a>
            </td>
        </tr>
        <tr class="print">
            <td>Goşmaça</td>
            <td>
                <a href="/workers/arzaout/{{$worker->id}}">
                    Arza çykyş
                </a>
            </td>
        </tr>
        <tr class="print">
            <td>Goşmaça</td>
            <td>
                <a href="/contract2/{{$worker->id}}">
                    Şertnama 2
                </a>
            </td>
        </tr>
        <tr class="print">
            <td>Goşmaça</td>
            <td>
                <a href="/buyruk/{{$worker->id}}">
                    Buyruk
                </a>
            </td>
        </tr>
    </table>
</body>
</html>