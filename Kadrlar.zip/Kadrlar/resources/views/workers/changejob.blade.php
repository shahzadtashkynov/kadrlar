@extends('app')
@section('content')
    <h1>
        Changejob 
    </h1>
    <table class="table m-1">
            <tr>
                <th>№</th>
                <th>Ady</th>
                <th>Familiyasy</th>
                <th class="job">Wezipesi</th>
                <th class="salary">Aylyk zahmet haky</th>
                <th class="adress">Salgysy</th>
                <th class="phone">Telefony</th>
            </tr>
            <form action="/changejob" method="post">
            <tr> 
                <td>{{$worker->id}}</td>
                <td>{{$worker->name}}</td>
                <td>{{$worker->surname}}</td>
                <td>
                        <input type="hidden" name="_token"
                        value="{{ csrf_token() }}">
                        <input type="hidden" name="id" value="{{$worker->id}}">    
                        <input type="text" name="job" placeholder="{{$worker->job}}" class="input">
                    </td>
                    <td class="salary">{{$worker->salary}}</td>                
                    <td class="adress">{{$worker->adress}}</td>
                    <td class="phone">{{$worker->phone}}</td>
                </tr>
            </table>        
            <input type="submit" value="Wezipesini chalyshmak" class="btn-blu">
            </form>
@endsection