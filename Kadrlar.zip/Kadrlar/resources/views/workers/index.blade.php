@extends('app')
@section('content')

    <div class="container">
        <h1 class="header">
            Telekeçi Annageldiyew "Arçalyk" suw zawodynyň we "Arçalyk" HJ-nyň işgärler sanawy
        </h1>
        <table class="table m-1">
            <tr>
                <th>№</th>
                <th>Ady</th>
                <th>Familiyasy</th>
                <th class="job">Wezipesi</th>
                <th class="salary">Aylyk zahmet haky</th>
                <th class="adress">Salgysy</th>
                <th class="phone">Telefony</th>
                <th class="operations">Amallar</th>
                <th class="operations">Boshatmak</th>
            </tr>
            @foreach($workers as $worker)
            <tr> 
                <td>{{$worker->id}}</td>
                <td>{{$worker->name}}</td>
                <td>
                    <a href="/workers/{{$worker->id}}">   
                    {{$worker->surname}}
                    </a>
                </td>
                <td>
                    {{$worker->job}}
                </td>
                <td class="salary">{{$worker->salary}}</td>                
                <td class="adress">{{$worker->adress}}</td>
                <td class="phone">{{$worker->phone}}</td>
                <td class="operations">
                    <form action="/changejob" method="get">
                    <input type="hidden" name="id" value="{{$worker->id}}">
                    <input type="submit" value="Wezipe chalyshmak" class="btn-blu">
                    </form>                         
                </td>
                <td>
                    <form action="/status" method="get">
                    <input type="hidden" name="id" value="{{$worker->id}}">
                @if ($worker->status==='working')
                <input type="hidden" name="status" value="deactivate">
                    <input type="submit" value="Boshatmak" class="btn-red">
                @else
                <input type="hidden" name="status" value="working">
                    <input type="submit" value="Gaytarmak" class="btn-green">
                @endif
                </form>
                </td>
            </tr>
            @endforeach
        </table>
        <a href="/create" class="btn-green right m-1">Taze ishgar</a>
        </div>
  @stop
  