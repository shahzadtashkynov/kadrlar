<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOwnersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('owners', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('name', 100);
            $table->string('surname', 100);
            $table->string('fname', 100);
            $table->string('passser', 100)->nullable()->default('text');
            $table->string('passno', 100)->nullable()->default('text');;
            $table->string('pass_given_date', 100)->nullable()->default('text');
            $table->string('pass_giver', 100)->nullable()->default('text');
            $table->string('owner_nalog_no', 100)->nullable()->default('text');
            $table->string('region', 100)->nullable()->default('text');
            $table->string('city', 100)->nullable()->default('text');
            $table->string('village', 100)->nullable()->default('text');
            $table->string('street', 100)->nullable()->default('text'); 
            $table->string('homeno', 100)->nullable()->default('text');
            
            $table->string('comp_name', 100)->nullable()->default('text');
            $table->string('comp_fullname', 100)->nullable()->default('text');
            $table->string('comp_adress', 100)->nullable()->default('text');
            $table->string('comp_cert_year', 100)->nullable()->default('text');
            $table->string('comp_cert_month', 100)->nullable()->default('text');
            $table->string('comp_cert_day', 100)->nullable()->default('text');
            $table->string('comp_cert_no', 100)->nullable()->default('text');
            $table->string('comp_region', 100)->nullable()->default('text');
            $table->string('comp_city', 100)->nullable()->default('text');
            $table->string('comp_street', 100)->nullable()->default('text');
            $table->string('comp_home_no', 100)->nullable()->default('text');
            $table->string('comp_tel', 100)->nullable()->default('text');
            $table->string('comp_fax', 100)->nullable()->default('text');
            $table->string('comp_email', 100)->nullable()->default('text');
            $table->string('comp_website', 100)->nullable()->default('text');
            $table->string('comp_birja_bashlyk', 100)->nullable()->default('text');
            
            $table->string('en_region', 100)->nullable()->default('text');
            $table->string('en_city', 100)->nullable()->default('text');
            $table->string('en_village', 100)->nullable()->default('text');
            $table->string('en_street', 100)->nullable()->default('text'); 
            $table->string('en_homeno', 100)->nullable()->default('text');
            $table->timestamps();
        });
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('owners');
    }
}
