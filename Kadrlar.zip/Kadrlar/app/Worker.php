<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Worker extends Model
{
    public $fillable=[
        'phpath',
        'name',
        'surname',
        'fname',
        'job',
        'salary',
        'adress',
        'passport_no',
        'passport_who',
        'passport_cpath',
        'trud_no',
        'phone',
        'status',
        'in_date',
        'out_date',
        'created_at',
        'updated_at'
    ];
}
