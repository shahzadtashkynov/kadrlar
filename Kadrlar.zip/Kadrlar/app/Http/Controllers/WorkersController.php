<?php

namespace App\Http\Controllers;
use App\Worker;
use Illuminate\Http\Request;
use App\Http\Requests\CreateWorkerRequest;

class WorkersController extends Controller
{
   public function index()
   {
      $workers=Worker::all();
   	return view('workers.index',compact('workers'));
   }
   function create()
   {
   return view('workers.create');
   }
   public function store(CreateWorkerRequest $request)
   {
     $data['name']=$request->name;
     $imageName = $request->name.time().'-photo.'.request()->photo->getClientOriginalExtension();
     request()->photo->move('images', $imageName);
     $data['phpath']='images/'.$imageName;
     $data['surname']=$request->surname;
     $data['fname']=$request->fname;
     $data['job']=$request->job;
     $data['salary']=$request->salary;
     $data['adress']=$request->adress; 
     $data['passport_no']=$request->passport_no;
     $data['passport_who']=$request->passport_who;
     $cpath= $request->name.time().'-copy.'.$request->cpath->getClientOriginalExtension();
     $request->cpath->move('images',$cpath);
     $data['passport_cpath']='images/'.$cpath; 
     $data['trud_no']=$request->trud_no;
     $data['phone']=$request->phone; 
     $data['status']='working' ;
     Worker::create($data);
      return redirect('/');
   }
   public function getchangejob(Request $request)
   {
      $id=$request->id;
      $worker=Worker::find($id);
      return view('workers.changejob',compact('worker'));
   }
   public function postchangejob(Request $request)
   {
      $id=$request->id;
      $worker= Worker::find($id);
      $worker->job=$request->job;  
      $worker->save();    
      return redirect('/');
   }
   public function status(Request $request)
   {
      $id=$request->id;
      $worker=Worker::find($id);
      $worker->status=$request->status;
      $worker->save();
      return redirect()->back();
   }
   public function show(Request $request)
   {
      $id=$request->id;
      $worker=Worker::find($id);
      return view('workers.show',compact('worker'));
   }
   public function arzain(Request $request,$id)
   {
      $id=$request->id;
      $worker=Worker::find($id);
      return view('workers.arzain',compact('worker'));
   }
   public function arzaout(Request $request,$id)
   {
      $id=$request->id;
      return $id;
      $worker=Worker::find($id);
         return view('workers.arzaout',compact('worker'));
   }
   public function contract(Request $request)
   {
      $id= $request->id;
      // return $id;
      $worker=Worker::find($id); 
      return view('contract',compact('worker'));
   }
   public function contract2(Request $request)
   {
      $id=$request->id;
      $worker=Worker::find($id);
      return view('contract2',compact('worker'));
   }
   public function buyruk(Request $request)
   {
      $id=$request->id;
      $worker=Worker::find($id);
      return view('buyruk',compact('worker'));
  }
   public function birja(Request $request)
   {  
      $id=$request->id;
      $worker=Worker::find($id);
      return view('birja',compact('worker'));
   }
}
